import React,{ Component } from 'react';
import propTypes from 'prop-types';
import pathToRegexp from 'path-to-regexp';

export default class Switch extends Component{
	static contextTypes = {
		location:propTypes.object
	}
	constructor(props){
		super(props);
	}
	render(){
		const { children } = this.props;
		const { pathname } = this.context.location;
		for(let child=0;child<children.length;child++){
			const { path } = children[child].props;
			if(pathToRegexp(path,[],{end:false}).test(pathname)){
				return children[child];
			}
			
		}
		return null;
	}
}